#include <stdio.h>
char cell[9],num[9];
int i,j,t,m,n,o,p=0,q,c,x_win,o_win,draw;
double x_win_per,o_win_per,draw_per,sum;
FILE *sc;
void main_menu();
void print_chart()
{
    printf("\n\t     %c|%c|%c",cell[0],cell[1],cell[2]);
    printf("\n\t    __|_|__");
    printf("\n\t     %c|%c|%c",cell[3],cell[4],cell[5]);
    printf("\n\t    __|_|__");
    printf("\n\t     %c|%c|%c",cell[6],cell[7],cell[8]);
    printf("\n\t      | |  \n");
}
void insert(char ch)
{
    if(ch=='X'){
        x_win++;
        fseek(sc,0,0);
        fprintf(sc,"%d %d %d",x_win,o_win,draw);
    }
    if(ch=='O'){
        o_win++;
        fseek(sc,0,0);
        fprintf(sc,"%d %d %d",x_win,o_win,draw);
    }
}
void game()
{
    for(i=0;i<9;i++){
        cell[i]=' ';
        num[i]='0';
    }
    while(1){
        print_chart();
        printf("\n\n\t    O first or X?\n\t(0)O\t\t(1)X\n\t\t");
        scanf("%d",&t);
        if(t!=0&&t!=1){
            system("cls");
            printf("\n\tPlease enter a valid input!\n");
        }
        if(t==0||t==1){
            printf("\tEnter the cell numbers you want X/O to insert in\n\t");
            break;
        }
    }
    for(i=0;i<9;i++){
        if(i%2!=t){
            scanf("%d",&j);
            if(num[j-1]=='1'){
                system("cls");
                printf("\tNo cheating! Play again:)\n");
                game();
            }
            cell[j-1]='X';
            num[j-1]='1';
            system("cls");
            print_chart();
        }
        if(i%2==t){
            scanf("%d",&j);
            if(num[j-1]=='1'){
                system("cls");
                printf("\tNo cheating! Play again:)\n");
                game();
            }
            cell[j-1]='O';
            num[j-1]='1';
            system("cls");
            print_chart();
        }
        if(cell[0]==cell[1]&&cell[1]==cell[2]&&cell[0]!=' '){
        printf("\n\t%c has won",cell[0]);
        p=1;
        insert(cell[0]);
        break;
        }
        if(cell[3]==cell[4]&&cell[4]==cell[5]&&cell[3]!=' '){
        printf("\n\t%c has won",cell[3]);
        p=1;
        insert(cell[3]);
        break;
        }
        if(cell[6]==cell[7]&&cell[7]==cell[8]&&cell[6]!=' '){
        printf("\n\t%c has won",cell[6]);
        p=1;
        insert(cell[6]);
        break;
        }
        if(cell[0]==cell[3]&&cell[3]==cell[6]&&cell[3]!=' '){
        printf("\n\t%c has won",cell[3]);
        p=1;
        insert(cell[0]);
        break;
        }
        if(cell[1]==cell[4]&&cell[4]==cell[7]&&cell[1]!=' '){
        printf("\n\t%c has won",cell[1]);
        p=1;
        insert(cell[1]);
        break;
        }
        if(cell[2]==cell[5]&&cell[5]==cell[8]&&cell[2]!=' '){
        printf("\n\t%c has won",cell[2]);
        p=1;
        insert(cell[2]);
        break;
        }
        if(cell[0]==cell[4]&&cell[4]==cell[8]&&cell[0]!=' '){
        printf("\n\t%c has won",cell[0]);
        p=1;
        insert(cell[0]);
        break;
        }
        if(cell[2]==cell[4]&&cell[4]==cell[6]&&cell[2]!=' '){
        printf("\n\t%c has won",cell[2]);
        p=1;
        insert(cell[2]);
        break;
        }
    }
    if(p==0){
        printf("\n\tDraw");
        draw++;
        fseek(sc,0,0);
        fprintf(sc,"%d %d %d",x_win,o_win,draw);
    }
    printf("\n\t\t(0)Play Again\t\t(1)Main Menu\n\t\t");
    scanf("%d",&q);
    if(q==0){
        system("cls");
        game();
    }
    if(q==1){
        system("cls");
        main_menu();
    }
}
void help()
{
    system("cls");
    printf("\t\t\t\tHELP\n\n");
    printf("\tThis is your general two-player X/O game made with c. While playing, first select whether X or O will start first, then insert the cell  number in the chart you want to fill, cells will be      filled alternately with X/O. The following diagram shows the cell numbers of the game chart:\n");
    printf("\n\t      1|2|3");
    printf("\n\t     __|_|__");
    printf("\n\t      4|5|6");
    printf("\n\t     __|_|__");
    printf("\n\t      7|8|9");
    printf("\n\t       | |  \n");
    printf("\n\tFirst to make a straight line with their sign (X/O) wins,  if both fail, then the game draws.\n\n\t\t(0)Return\n\t");
    while(1){
        scanf("%d",&n);
        if(n==0){
            system("cls");
            main_menu();
            break;
        }
        else{
            printf("Please enter a valid input!\n\t");
        }
    }
}
void scores()
{
    sum=(x_win+o_win+draw);
    if(sum==0){
        x_win_per=0;
        o_win_per=0;
        draw_per=0;
    }
    else{
        x_win_per=(x_win*100.0/sum*1.0),o_win_per=(o_win*100.0/sum*1.0),draw_per=(draw*100.0/sum*1.0);
    }
    printf("\t\tScores\n\n");
    printf("\tX has won %d times (%.2lf%%).\n\tO has won %d times (%.2lf%%).\n\tThe game has drawn %d times (%.2lf%%)\n\n\t\t\n\n\t\t(1)Reset scores\n\n\t\t(0)Return\n\t",x_win,x_win_per,o_win,o_win_per,draw,draw_per);
    while(1){
        scanf("%d",&o);
        if(o==0){
            system("cls");
            main_menu();
            break;
        }
        if(o==1){
            x_win=0,o_win=0,draw=0;
            fseek(sc,0,0);
            fprintf(sc,"%d %d %d",x_win,o_win,draw);
        }
        else{
            printf("Please enter a valid input!\n\t");
        }
    }
}
void about()
{
    system("cls");
    printf("\t\t\t\tABOUT\n\n");
    printf("\tThis game was developed as a test project as a .c file.     \tHope you enjoy the game.\n\n\tDeveloper: MII\n\n\t\t(0)Return\n\t");
    while(1){
        scanf("%d",&o);
        if(o==0){
            system("cls");
            main_menu();
            break;
        }
        else{
            printf("Please enter a valid input!\n\t");
        }
    }
}
void main_menu()
{
    printf("\t\t    -----TIC-TAC-TOE-----");
    printf("\n\n\t    (0)Start Game     (1)Help\t  (2)About\n\n\t    (3)Scores        (Any other number)Exit    \n\n    (Enter any digit given against the options to activate them)\n   ");
    scanf("%d",&m);
    if(m==0){
        system("cls");
        game();
    }
    if(m==1){
        system("cls");
        help();
    }
    if(m==2){
        system("cls");
        about();
    }
    if(m==3){
        system("cls");
        scores();
    }
    else{
        fclose(sc);
        return 0;
    }
}
int main()
{
    sc=fopen("scores.txt","r+");
    if(sc==NULL){
        perror("scores.txt file could not be opened!\nError :");
        return 1;
    }
    fscanf(sc,"%d",&x_win);
    fscanf(sc,"%d",&o_win);
    fscanf(sc,"%d",&draw);
    main_menu();
    return 0;
}
