                ---------TIC-TAC-TOE---------

Version 1.4

Disclaimer:

This program does not contain any type of malware and hence any problem faced in any device after running this program is NOT to be credited to this program.

TIC-TAC-TOE v1.4

This is a basic two player X/O game made with c. Play the game by running the single .c file provided in the archive in any IDE. In this version, score system has been added.

----IMPORTANT----

Please keep the scores.txt file provided in the archive in the same folder as of the .c file to avoid error.

The game was developed as a test project. Hope you enjoy playing it.


Developer: MII